import CCTVForm from '@/components/cctv/cctvForm';

export default function Default() {
  console.log("form 디폴트");
  
  return (
    <div>
      <CCTVForm />
      디폴트
    </div>
  );
}

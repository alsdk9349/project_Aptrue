import CCTVWebRTC from '@/components/homePage/CCTV/CCTVWebRTC';

export default function Page() {
  return <CCTVWebRTC />;
}

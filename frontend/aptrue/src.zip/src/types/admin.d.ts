import NextAuth, {DefaultSession, User} from 'next-auth';

interface Admin {
    adminId: number;
    name: string;
    account: string;
    password:string;
    phone:string;
    createdAt:string;
}

interface postAdmin {
    account:string;
    name:string;
    password:string;
    phone:string;
}

interface postLogin {
    account:string;
    password:string;
}

declare module 'next-auth' {
    interface Session extends DefaultSession {
        user: {
            account:string
        } & DefaultSession['user'];
        accessToken:string;
    }
}
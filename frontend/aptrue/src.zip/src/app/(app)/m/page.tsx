export default function MobileHome() {
  return <></>;
}

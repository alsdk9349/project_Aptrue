import CCTVForm from '@/components/cctv/cctvForm';

export default function Page() {
  return (
    <div>
      <CCTVForm />
    </div>
  );
}
